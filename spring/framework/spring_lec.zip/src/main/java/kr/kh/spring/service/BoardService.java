package kr.kh.spring.service;

import java.util.List;

import kr.kh.spring.model.vo.BoardVO;

public interface BoardService {

	List<BoardVO> selectBoardList();
	
}
