package kr.kh.spring.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import kr.kh.spring.model.vo.BoardVO;

@Mapper
public interface BoardDAO {


	List<BoardVO> selectBoardList();

}
