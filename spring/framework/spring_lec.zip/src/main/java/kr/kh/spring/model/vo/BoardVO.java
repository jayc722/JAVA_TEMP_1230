package kr.kh.spring.model.vo;

import lombok.Data;

@Data
public class BoardVO {

		private int bo_num;
		private String bo_name;
	
}
