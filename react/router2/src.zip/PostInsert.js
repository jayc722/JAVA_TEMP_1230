
function PostInsert(){
	return(
		<div>
			<h1>게시글 등록</h1>

		</div>


	)



}

export default PostInsert;